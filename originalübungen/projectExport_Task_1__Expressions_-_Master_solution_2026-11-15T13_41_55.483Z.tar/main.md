# Solution

### Expression 1: **valid, l-value, `5`**

`a = b = 5` is a valid expression. 
It is parenthesized as `a = (b = 5)`.
The expression is a l-value (memory location of `a`) and its value is 5.
    
### Expression 2: **invalid**

`1 = a` is not a valid expression. 
`1` is an r-value and cannot stand at the left side of an assignment.


### Expression 3: **valid, r-value, `(a + 1) + b`**

`++a + b++` is a valid expression. 
It is parenthesized as `(++a) + (b++)`. 
The expression is an addition of two variables, and therefore an r-value.
It evaluates to `(a + 1) + b`, as calculated from the initial values of  `a` and `b`.


### Expression 4: **invalid**

`a + b = c + d` is not a valid expression. Left hand side is an r-value.


### Expression 5: **invalid**

`a = 2 b` is not a valid expression. 
The right hand side is syntactically incorrect (missing operator).