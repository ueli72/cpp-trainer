#pragma once

// PRE: A number >= 0 in base 10, and a base 1 < b < 10
//
// POST: Return the number in base b, i.e., return the number whose digits 
//       are the digits of the representation of the input number n in base b
//
// Examples:
//    * 10 2 ~~> 1010
//    * 14 9 ~~> 15
int convert_base(int n, int b) {
  int result = 0;
  int basetenposition = 1;
  
  while (n != 0) {
    result += basetenposition * (n % b);
    n = n / b;
    basetenposition *= 10;
  }
  
  return result;
}
