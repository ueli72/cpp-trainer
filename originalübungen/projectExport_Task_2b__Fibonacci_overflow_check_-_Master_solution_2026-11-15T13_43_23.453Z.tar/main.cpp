#include <iostream>

int main() {
  const int max_int_32bits = 2147483647; // 2^31 - 1
  // One bit is used to store the sign (positive or negative), so we have
  // 32 - 1 = 31 bits left.

  int max_count;
  std::cout << "Enter how many Fibonacci numbers to print: ";
  std::cin >> max_count;
  
  int count = 0;
  
  int fib_prev = 1; // Initialise to 1, to bootstrap the computation F_(i+1) = F_i + F_(i-1)
  int fib_curr = 0;
  bool overflow = false;

  // Try all Fibonacci numbers until max_count reached oder overflow would occur
  for (; count < max_count && !overflow; ++count) {
    std::cout << fib_curr << '\n';

    // Check for overflow
    overflow = fib_curr > max_int_32bits - fib_prev;

    // Compute next Fibonacci number
    if (!overflow) {
      const int fib_next = fib_curr + fib_prev;
      fib_prev = fib_curr;
      fib_curr = fib_next;
    }
  }

  std::cout << "Printed " << count << " of " << max_count << " Fibonacci numbers\n";
  
  return 0;
}
