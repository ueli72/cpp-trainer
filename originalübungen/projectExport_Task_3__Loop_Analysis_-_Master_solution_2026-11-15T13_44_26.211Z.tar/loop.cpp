#include <iostream>

// Fill out the file with the required answers


/*

  Subtask 1: Describe the output of the program as a function of its input n.

  The program computes x = 2^n.

*/

/*

  Subtask 2: For which values of n do you expect a correct output x? Explain why.

  The critical point is the value range of x, of type `int`, since x
  increases exponentially. On 32-bit systems for example a common maximum 
  value for `int` is given by (2^31)-1, resulting in invalid results 
  for inputs of n >= 31. The range of inputs producing correct \
  outputs would then be n in {0, ..., 30}.

*/


/*

  Subtask 3: Show that this program terminates for all values of n found in (2).
  
  For n = 0, the program terminates after not entering the `if`-block.

  For n = 1, the program enters the `if`-block. 
  Since `--n == 0` evaluates to `true` (for n = 1), `e` is set to `false` during the first iteration of the `do-while`-loop. 
  This causes the `do-while`-loop to stop and the program to terminate.

  Assuming that the program terminates for n-1, we now show that the program must also terminate for n. 
  During the evaluation of the `if`-statement (`--n == 0`), n is decreased by one. 
  Since we know that the program terminates for n-1, it follows that the program must also terminate for n.

  
*/ 

/*
  Subtask 4: Provide a more elegant implementation of this function using 
  another type of loop.
*/

void loop(){
  
  int n;
  std::cin >> n;
  
  int x = 1;
  while (n > 0) {
     x *= 2;
     --n;
  }
  std::cout << x << std::endl;
  
}

int main() {
    loop();
    return 0;
}
