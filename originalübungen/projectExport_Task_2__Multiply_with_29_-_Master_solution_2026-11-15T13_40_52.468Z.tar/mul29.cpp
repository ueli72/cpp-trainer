// program that multiplies a number by 29 using only additions

#include <iostream>

int main() {
  // input
  std::cout << "Please enter a number: ";
  int a;
  std::cin >> a;
  
  // computation
  int b = a + a; // b = 2a
  int c = b + b; // c = 4a
  int d = c + c; // d = 8a
  int e = d + d; // e = 16a

  // output result (16 + 8 + 4 + 1) * a;
  std::cout << "29 * " << a << " = ";
  std::cout << e + d + c + a << "\n";
  return 0;
}