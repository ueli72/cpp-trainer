#include <iostream>
// Enable vectors
#include <vector>

// PRE: -
// POST: integers from input up to the first negative one
//       have been read, and non-negative appended to values in order
//       of appearance
void read_vector(std::vector<int>& values) {
    // Loop and store integers until encountering a negative one
    int iread;
    while (true) {
        std::cin >> iread;
        if (iread < 0) {
            return;
        }
        values.push_back(iread);
    }
}

// PRE: -
// POST: return the number of occurrences of toFind in values.
int occurrences(const std::vector<int>& values, int to_find) {
    // Count number of occurrences by scanning the vector
    int count = 0;
    for (int i = 0; i < std::ssize(values); ++i) {
        if (values[i] == to_find) {
            ++count;
        }
    }
    return count;
}

int main() {

    std::vector<int> values = std::vector<int>(0); 
    read_vector(values);

    // Read number of interest
    int to_find;
    std::cin >> to_find;

    // Output result
    std::cout << occurrences(values, to_find) << "\n";
    return 0;

}
