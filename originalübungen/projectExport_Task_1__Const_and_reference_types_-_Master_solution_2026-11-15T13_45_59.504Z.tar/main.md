
1. 

```c++
int foo(int i) {
    return ++i;
}
```

a) No, because there is no constness at all.

b) Well-defined. The function returns a copy of the value of `i+1`.

c) `POST: returns initial value of i incremented by 1`.

2. 

```c++
int foo(const int i) {
    return ++i;
}
```

a) Yes, the function attempts to modify `i`.

b) N/A

c) N/A

3.

```c++
int foo(int& i) {
    return ++i;
}
```

a) No, because there is no constness at all.

b) Well-defined. The function returns a copy of the value of `i+1`.

c) `POST: increments i by 1 and returns new value of i.`

4. 

```c++
int& foo(int i) {
    return ++i;
}
```

a) No, because there is no constness at all.

b) It is not well-defined what the returned value is and what the side effects are. A reference to `i` is returned, but the address of `i` in memory is free after the execution of `foo`, so the value stored in that reference may change during the execution of the program.

c) N/A

5. 

```c++
const int& foo(int& i) {
    return ++i;
}
```

a) No, it is allowed to return a const reference.

b) Well-defined. The function returns a reference pointing to the same location pointed by `i`. Furthermore, the value pointed by `i` is increased by 1.

c) `POST: increments i by 1 and returns a const reference to i.`

---
Note that this solution ignores the fact that in all 5 cases an overflow can occur.
Since we are dealing with (signed) `int` here, the overflow (or underflow) is NOT well-defined, but you can ignore this for solving this task.
