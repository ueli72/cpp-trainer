#include <iostream>

// Fill out the file with the required answers


/*

  Subtask 1: describe what the code snippet computes

  The snippet computes the factorial.

*/

/*

  Subtask 2: decide which of the other two kind of loops would fit better, and
  describe why.

  (Note that for this sub task, there is no exact answer.) The `do-while` version 
  is unsuitable because the condition has to be checked at the beginning anyway. 
  The `while` version is better, but the `for` version is the most concise 
  and probably the most suited since we have counting loop here.

*/


/*
  Subtask 3: update the function below by rewriting the snippet into the 
  loop you specified in (2)
*/

void loop(){
  
  int n;
  std::cin >> n;

  int f;
  for (f = 1; n > 0; --n) {
    f = f * n;
  }
  std::cout << f << "\n";
  
}

int main() {
    loop();
    return 0;
}
