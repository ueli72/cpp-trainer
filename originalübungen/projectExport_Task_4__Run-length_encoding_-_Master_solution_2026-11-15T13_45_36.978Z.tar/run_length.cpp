#include "run_length.h"

// PRE:  n/a
// POST: returns true if value equals the maximal run-length
bool is_max_runlength(int value) {
    return value == 255;
}

// PRE:  n/a
// POST: outputs value and adds a space
void out_byte(int value) {
    std::cout << value << " ";
}

// PRE:  n/a
// POST: returns true if 0 <= value <= 255, otherwise false
bool is_byte(int value) {
    return 0 <= value && value <= 255;
}

// PRE:  1 <= runlength <= 255, and value is a byte.
// POST: outputs run length encoded bytes of tuple
void output(int run_length, int value) {
    assert(1 <= run_length && run_length <= 255);
    assert(is_byte(value));

    out_byte(run_length);
    out_byte(value);
}

// PRE:  n/a
// POST: outputs "error" if value does not indicate end of sequence, "-1" otherwise.
void end_of_sequence(int value) {
    if (value != -1) {
        std::cout << "error";
    } else {
        std::cout << "-1";
    }
}

// PRE:  standard input has to end in "-1"
// POST: reads byte sequence and outputs encoded bytes
void encode() {
    //std::cout << "encoding: enter byte sequence, terminate with -1\n";
    
    // output start of sequence
    std::cout << "1 ";
    
    int value;
    std::cin >> value;

    if (is_byte(value)) {
        int prev_value = value;
        int run_length = 1;
        
        // Usually, we would discourage writing 'endless' loops like
        // this. Nevertheless you may encounter these in the wild 
        // when the end of the loop is not easily determined by a single
        // statement. A typical example would also be server applications
        // or daemons, that are supposed to run until they are terminated
        // by a signal outside the program.
        // While one could rewrite this loop to, e.g., use functions to
        // group the statements leading to termination, because of the
        // dependence of the termination condition on user input, 
        // and in favor of simplicity, we deem a while(true) loop ok here.
        while (true) {

            // read next byte, stop if invalid or end of sequence
            std::cin >> value;
            if (!is_byte(value)) {
                break;
            }

            // output if value has changed or maximal runlength is reached
            // otherwise increase length of current run
            if (value != prev_value || is_max_runlength(run_length)) {
                output(run_length, prev_value);
                run_length = 1;
                prev_value = value;
            } else {
                ++run_length;
            }
        }

        output(run_length, prev_value);
    }

    // output "error" if sequence terminated incorrectly, -1 if correctly.
    end_of_sequence(value);
}

// PRE:  standard input has to end in "-1"
// POST: reads byte sequence and outputs decoded bytes
void decode() {
    // output start of sequence
    std::cout << "0 ";
    
    int value;
    while (true) {

        // read run length, stop if invalid or end of sequence
        std::cin >> value;
        if (!is_byte(value)) {
            break;
        }
        int run_length = value;

        // next must be a valid byte, otherwise this is an error
        std::cin >> value;
        if (!is_byte(value)) {
            value = 0; // trigger error in case value = -1
            break;
        }

        // output uncompressed tuple
        for (int i = 0; i < run_length; ++i) {
            out_byte(value);
        }
    }

    // output "error" if sequence terminated incorrectly, -1 if correctly.
    end_of_sequence(value);
}