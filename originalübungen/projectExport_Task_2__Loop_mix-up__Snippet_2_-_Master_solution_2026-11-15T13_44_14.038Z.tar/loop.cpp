#include <iostream>

// Fill out the file with the required answers


/*

  Subtask 1: describe what the code snippet computes

  The snippet repeatedly computes the sum of two user provided integer numbers.

*/

/*

  Subtask 2: decide which of the other two kind of loops would fit better, and
  describe why.

  
  (Note that for this sub task, there is no exact answer.) 
  The presented `for` version is inelegant because it creates an infinite loop
  that is ended with `break`.  While this can be avoided, the `do-while` is
  more natural here because it directly reflects the fact that the body runs at
  least once.
  
  A `while` loop would be slightly preferred over a `for` loop in this case
  since there is no clear counting variable that is incremented each loop 
  iteration until the termination condition is reached. However, the `do-while`
  version is still the most natural here.

*/


/*
  Subtask 3: update the function below by rewriting the snippet into the 
  loop you specified in (2)
*/

void loop(){

  int again;
  do {
    int i1, i2;
    std::cin >> i1 >> i2;
    std::cout << i1 + i2 << "\n";

    std::cout << "Again? (0/1)\n";
    std::cin >> again;
  } while (again != 0);
}

int main() {
    loop();
    return 0;
}

