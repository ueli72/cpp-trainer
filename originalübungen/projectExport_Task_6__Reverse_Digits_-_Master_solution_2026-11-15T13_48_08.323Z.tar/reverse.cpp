#include "reverse.h"
#include <iostream>

// PRE: n >= 0
// POST: print the digits of the input in reverse order to std::cout
void reverse(int n)
{
  // base condition to end recursive calls
  if (n < 10) {
    std::cout << n;
  } else {
    std::cout << n % 10;
    reverse(n / 10);
  }
}