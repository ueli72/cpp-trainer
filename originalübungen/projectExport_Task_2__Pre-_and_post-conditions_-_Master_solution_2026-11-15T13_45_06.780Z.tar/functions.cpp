// PRE: (x >= 0) && ((n != 0) || (x != 0))
// POST: returns n^x
int f1(int n, int x) {
  int res = 1;
  for (; x > 0; x--) {
    res *= n;
  }
  return res;
}
// The fragment (n != 0) || (x != 0) avoids computing 0^0.
// Note that depending on the context, 0^0 may be defined, so multiple
// Preconditions could be correct here.
// https://en.wikipedia.org/wiki/Zero_to_the_power_of_zero

// PRE:  n > 0
// POST: returns number of digits of n
int f2(int n) {
  int i = 0;
  while (n > 0) {
    n = n / 10;
    ++i;
  }
  return i;
}

// PRE:  (n != 1) && (n != -1)
// POST: returns true if n is a prime number, else false
bool f3(int n) {
  int i = 2;
  for (; n % i != 0; ++i);
  return n == i;
}

// PRE:  n must be a positive perfect square (multiplication of two identical integers)
// POST: returns (non-negative) square root of n
int f4(int n) {
  int i = 0;
  while (i * i != n) {
    ++i;
  }
  return i;
}
