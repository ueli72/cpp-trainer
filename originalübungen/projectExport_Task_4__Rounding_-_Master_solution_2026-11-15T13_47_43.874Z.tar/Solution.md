# Solution

By the C++ standard, converting a floating point number to `c++|int` cuts off the fractional part. Then, we compute the difference between the original number and its truncation. Under the IEEE standard 754, this difference has less significant binary digits than the original number, but those which it still has, are the same. Thus, normalizing this number works by simply adjusting the exponent and filling up the emerging digits with $0$. Therefore the truncated number is exactly representable as a `c++|double` value.

Now we can exactly test whether the difference is less than $0.5$ (in which case we return the truncation), or at least $0.5$ (in which case we return the next integer, going away from zero).
