#include <iostream>

int main() {
  // input m
  int m;
  std::cin >> m;

  // computation of sum 1
  
  // the original formula in the task description
  /*
  double pi1_4 = 0.0;
  for (int j = 0; j < m; ++j) {
    if (j % 2 == 0) {
      pi1_4 += 1.0 / (2 * j + 1);
    } else {
      pi1_4 -= 1.0 / (2 * j + 1);
    }
  }
  double pi1 = 4.0 * pi1_4;
  */
  
  // an optimized form
  double pi1 = 0.0;
  for (int j = 1; j < 2 * m; j += 2) {
    if (j % 4 == 1) {
      pi1 += 4.0 / j;
    } else {
      pi1 -= 4.0 / j;
    }
  }
  
  // output
  std::cout << "sum 1: " << pi1 << "\n";

  return 0;
}