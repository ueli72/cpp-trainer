#pragma once

#include <iostream>
#include <cmath>

// TODO: Write structure declaration/operators forward declarations here.

// ...

// reads a complex number from input
std::istream& operator>>(std::istream& in, Complex& a);
