#include "complex.h"

std::istream& operator>>(std::istream& in, Complex& a) {
    char c; // separating characters '[', ',' and ']'
    /* TODO: Finish implementation */
    return in;
}

// TODO: Write all the operators and functions implementations here.
