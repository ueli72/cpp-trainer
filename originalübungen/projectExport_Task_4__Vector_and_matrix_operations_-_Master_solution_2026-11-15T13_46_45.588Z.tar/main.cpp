#include <iostream>
// Enable std::vectors
#include <vector>

#include "io.h"

using vec = std::vector<int>;
using mat = std::vector<vec>;

// POST: result of dot product of v1 and v2 is printed to standard output,
// or "error" if dimensions are not compatible
void dot_product(const vec& v1, const vec& v2) {
  if (std::ssize(v1) != std::ssize(v2)) {
    std::cout << "error\n";
    return;
  }
  int res = 0;
  for (int i = 0; i < std::ssize(v1); ++i) {
    res += v1[i] * v2[i];
  }
  print_scalar(res);
}

// PRE: m is a bi-dimensional vector (matrix) with non-zero dimensions
// POST: result of matrix-vector product m * v is printed to
// standard output, or "error" if dimensions are not compatible.
void matrix_vector_product(const mat& m, const vec& v) {
  if (std::ssize(m[0]) != std::ssize(v)) {
    std::cout << "error\n";
    return;
  }
  vec res = vec(std::ssize(m), 0);
  for (int row = 0; row < std::ssize(m); ++row) {
    for (int col = 0; col < std::ssize(v); ++col) {
      res[row] += m[row][col] * v[col];
    }
  }
  print_vector(res);
}

// PRE: m1 and m2 are bi-dimensional vectors (matrices) with non-zero dimensions
// POST: result of matrix product m1 * m2 is printed to standard output,
// or "error" if dimensions are not compatible.
void matrix_product(const mat& m1, const mat& m2) {
  if (std::ssize(m1[0]) != std::ssize(m2)) {
    std::cout << "error\n";
    return;
  }
  mat res = mat(std::ssize(m1), vec(std::ssize(m2[0]), 0));
  for (int row = 0; row < std::ssize(m1); ++row) {
    for (int col = 0; col < std::ssize(m2[0]); ++col) {
      for (int mid = 0; mid < std::ssize(m2); ++mid) {
        res[row][col] += m1[row][mid] * m2[mid][col];
      }
    }
  }
  print_matrix(res);
}

int main() {
  std::cout << "Left operand" << std::endl;
  char left_type;
  std::cin >> left_type;

  if (left_type == 'v') {
    // left operand is vector

    // get vector from input
    vec left_operand;
    read_vector(left_operand);

    // get right operand type
    std::cout << "Right operand" << std::endl;
    char right_type;
    std::cin >> right_type;

    if (right_type == 'v') {
      // right operand is a vector => compute dot product

      // get vector from input
      vec right_operand;
      read_vector(right_operand);

      // compute dot product
      dot_product(left_operand, right_operand);
    } else {
      // right operand is anything but a vector => error
      std::cout << "error";
    }

  } else if (left_type == 'm') {
    // left operand is matrix

    // get matrix from input
    mat left_operand;
    read_matrix(left_operand);

    // get right operand type
    std::cout << "Right operand" << std::endl;
    char right_type;
    std::cin >> right_type;

    if (right_type == 'v') {
      // right operand is vector => compute matrix-vector product

      // get vector from input
      vec right_operand;
      read_vector(right_operand);

      // compute matrix-vector product
      matrix_vector_product(left_operand, right_operand);
    } else if (right_type == 'm') {
      // right operand is a matrix => compute matrix-matrix product

      // get matrix from input
      mat right_operand;
      read_matrix(right_operand);

      // compute matrix-matrix product
      matrix_product(left_operand, right_operand);
    } else {
      // right operand is anything but a vector or a matrix => error
      std::cout << "error";
    }

  } else {
    // left operand is anything but a vector or a matrix => error
    std::cout << "error";
  }
  std::cout << std::flush;
  return 0;
}
