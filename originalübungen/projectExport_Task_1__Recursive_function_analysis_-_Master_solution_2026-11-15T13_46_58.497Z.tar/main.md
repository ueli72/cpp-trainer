1. i) Pre- and post conditions
    ```c++
    // PRE:  n >= 0
    // POST: return value is false if n is even and true if n is odd
    ```
    
    ii) The function `plain|f` immediately terminates for `plain|n == 0`. With each recursive call `plain|n` is decremented, i.e., `plain|f` is called with parameter `plain|< n`, eventually reaching `plain|n = 0`.
    
    iii) $\text{Calls}_{f}(n) = n+1$ (including first non-recursive function call)


2. i) Pre- and post conditions
    ```c++
    // PRE:  n >= 0
    // POST: 2^n stars have been written to standard output
    ```
    
    ii) The function `plain|g` immediately terminates for `plain|n == 0`. With each recursive call `plain|n` is decremented, i.e., `plain|g` is called with parameter `plain|< n`, eventually reaching `plain|n = 0`. This is true for both recursive calls of `plain|g`.
    
    iii) $\text{Calls}_{g}(n) = \sum_{i=0}^n{2^i} = 2^{n+1}-1$ (including first non-recursive function call)