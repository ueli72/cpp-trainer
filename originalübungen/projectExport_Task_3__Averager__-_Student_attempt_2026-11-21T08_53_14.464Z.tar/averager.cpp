#include "averager.h"

// Write implementation of methods of class Averager here