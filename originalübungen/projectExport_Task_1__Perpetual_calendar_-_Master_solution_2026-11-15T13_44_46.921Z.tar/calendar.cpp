#include "calendar.h"

// PRE: a year greater or equal than 1900
// POST: returns whether that year was a leap year
bool is_leap_year(int year) {
  assert(year >= 1900);
  return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
}

// PRE: a year greater or equal than 1900
// POST: returns the number of days in that year
int count_days_in_year(int year) {
  assert(year >= 1900);
  if (is_leap_year(year)) {
    return 366;
  } else {
    return 365;
  }
}

// PRE: a month between 1 and 12 and a year greater or equal than 1900
// POST: returns the number of days in the month of that year
int count_days_in_month (int month, int year) {
  assert(year >= 1900);

  int days;
  switch (month) {
      case 2:
        days = 28;
        if (is_leap_year(year)) {
          days += 1;
        }
        break;
      case 4: 
      case 6: 
      case 9: 
      case 11: days = 30; break;
      case 1: 
      case 3:
      case 5:
      case 7:
      case 8:
      case 10:
      case 12: days = 31; break;
      default: assert(false); //happens iff month out of range 1-12
  }
  return days;
}

// PRE:  n/a
// POST: returns whether the given values represent a valid date
bool is_valid_date(int day, int month, int year) {
  return year >= 1900 && month >= 1 && month <= 12 &&
      day >= 1 && day <= count_days_in_month(month, year);
}

// PRE: the given values represent a valid date
// POST: returns the number of days between January 1, 1900 and this date (excluding this date)
int count_days(int day, int month, int year) {
  assert(is_valid_date(day, month, year));

  int result = 0;

  // account for remaining days in this month
  result += day - 1;

  // sum up all remaining days in this year
  while (--month >= 1) result += count_days_in_month(month, year);

  // sum up all remaining days until 1900
  while (--year >= 1900) result += count_days_in_year(year);

  return result;
}

// PRE: the given values represent a (potentially invalid) date
// POST: prints the weekday if the date is valid or "invalid date" otherwise.
//      Everything must be printed in lowercase.
void print_weekday(int day, int month, int year) {
  // check for valid input

  if (!is_valid_date(day, month, year)) {
      std::cout << "invalid date\n";
      return;
  }

  // compute the weekday
  int weekday = count_days(day, month, year) % 7;

  // output the weekday
  switch (weekday) {
      case 0: std::cout << "monday\n";    break;
      case 1: std::cout << "tuesday\n";   break;
      case 2: std::cout << "wednesday\n"; break;
      case 3: std::cout << "thursday\n";  break;
      case 4: std::cout << "friday\n";    break;
      case 5: std::cout << "saturday\n";  break;
      case 6: std::cout << "sunday\n";    break;
  }
}