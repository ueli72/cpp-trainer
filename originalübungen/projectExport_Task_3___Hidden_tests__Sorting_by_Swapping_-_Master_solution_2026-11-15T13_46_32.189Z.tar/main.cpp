#include "sort.h"
#include "assert.h"

int main() {

    int length;
    std::cin >> length;
    
    std::vector<int> values(length);
    
    process_vector(values);
    
    //check that the vector is still the same size
    assert(std::ssize(values) == length);
    
    return 0;
}