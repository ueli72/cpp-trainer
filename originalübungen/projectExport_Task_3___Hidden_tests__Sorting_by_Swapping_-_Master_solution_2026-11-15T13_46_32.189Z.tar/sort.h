#pragma once
#include <iostream>
// Enable vectors
#include <vector>

void process_vector(std::vector<int>& values);