#include "sort.h"

// PRE: -
// POST: fill values with values a_1 ... a_n where standard input starts with a_1 ... a_n,
//       and n = values.size()
void read_vector(std::vector<int>& values) {
    for (int i = 0; i < std::ssize(values); ++i) {
        std::cin >> values[i];
    }
}

// PRE: -
// POST: values is sorted in decreasing order
void bubble_sort(std::vector<int>& values) {
    // iterate and swap
    bool swapped;
    do {
        swapped = false;
        for (int i = 1; i < std::ssize(values); ++i) {
            if (values[i] > values[i-1]) {
                int temp = values[i];
                values[i] = values[i-1];
                values[i-1] = temp;
                swapped = true;
            }
        }
    } while (swapped);
}

// PRE: -
// POST: content of values has been printed to standard output.
void print_vector(const std::vector<int>& values) {
    for (int i = 0; i < std::ssize(values); ++i) {
        std::cout << values[i] << " ";
    }
    std::cout << "\n";
}

void process_vector(std::vector<int>& values) {
  read_vector(values);
  bubble_sort(values);
  print_vector(values);
}