# Function  `c++|is_even`:

The problem with this function is that no `c++|return` statement is executed if the parameter `c++|i` is odd. This problem can be solved like this:
```c++
// POST: returns true if and only if i is even
bool is_even(int i) {
  return i % 2 == 0;
}
```
The function works for any value of `c++|i` and needs therefore no precondition.

# Function `c++|invert`:

The problem with this function is that the variable `c++|result` is not initialized properly. In case `c++|x` is zero this leads to undefined behavior (reading an uninitialized variable).  
There are two possibilities to fix this function: either make `c++|x != 0` a precondition (1) or return a special value in this case (2).  
Variant (1):
```c++
// PRE: x is not zero
// POST: returns the inverse of x
double invert(int x) {
  assert(x != 0);
  return 1.0 / x;
}
```
Variant (2):
```c++
// POST: returns either the inverse of x, or zero if x is zero
double invert(int x) {
  double result = 0;
  if (x != 0) {
      result = 1.0 / x;
  }
  return result;
}
```