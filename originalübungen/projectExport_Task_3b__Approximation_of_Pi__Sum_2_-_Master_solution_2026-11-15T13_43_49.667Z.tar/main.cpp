#include <iostream>

int main() {
  // input m
  int m;
  std::cin >> m;

  // computation of sum 2
  
  // the original formula in the task description
  /*
  double pi2_2 = 1.0; // first term
  // sum formula
  for (int j = 1; j < m; ++j) {
    double numer = 1.0;
    for (int i = 1; i <= j; ++i) {
      numer *= i;
    }
    double denom = 1.0;
    for (int i = 1; i <= j; ++i) {
      denom *= 2 * i + 1;
    }
    pi2_2 += numer / denom;
  }
  double pi2 = 2.0 * pi2_2;
  */
   
  // an optimized form
  double pi2 = 2.0;
  // initialize auxiliary variables
  double numer = 2.0; // numerator i-th term
  double denom = 1.0; // denominator i-th term
  // sum formula
  for (int j = 1; j < m; ++j) {
    numer *= j;
    denom *= 2 * j + 1;
    pi2 += numer / denom;
  }

  // output
  std::cout << "sum 2: " << pi2 << "\n";

  return 0;
}

// Sum 2 gives a more precise approximation of pi than sum 1 with the same
// number of terms. However, it is important to decide at which point to stop
// the computation: the terms in numerator and denominator quickly grow beyond
// the capacity of type double, resulting in "not a number" result.