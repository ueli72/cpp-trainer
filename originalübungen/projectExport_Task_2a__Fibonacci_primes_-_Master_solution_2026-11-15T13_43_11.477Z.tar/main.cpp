#include <iostream>

int main() {
  std::cout << "Enter a positive integer: ";

  int m;
  std::cin >> m;

  // try all fibonacci numbers
  int prev_n = 1;
  int count = 0;

  for (int n = 2; n <= m;) {
    
    // test if n is prime
    int d;
    for (d = 2; (n % d != 0); ++d);

    if (d == n) {
      // found fibonacci prime
      std::cout << n << "\n";
      ++count;
    }

    // compute next fibonacci number
    int next_n = n + prev_n;
    prev_n = n;
    n = next_n;
  }

  std::cout << "Found " << count << " Fibonacci primes\n";
    
  return 0;
}
