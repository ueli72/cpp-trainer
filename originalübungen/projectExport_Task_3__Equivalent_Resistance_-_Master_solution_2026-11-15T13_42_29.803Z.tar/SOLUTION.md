# Solution

Keys for the solution are the rules for serial and parallel circuits:

(1) $R_{12} = R_1 + R_2$

(2) $R_{34} = R_3 + R_4$

(3) $1/R_{1234} = 1/R_{12} + 1/R_{34} \quad \Longrightarrow\quad  R_{1234} = (R_{12}\cdot R_{34}) / (R_{12} + R_{34}),$

and the rule for arithmetic rounding (using the symbol $\div$ for integer division)

$\lfloor a/b+1/2 \rfloor = (a + b \div 2) \div b.$

$\qquad$

**Remark:** the rule for arithmetic rounding can be proven as follows. This is
not expected in your solution but interesting background information:

It holds that

$\qquad a \div b = \max\{n\in\Bbb{N}: b\cdot n \leq a\}$.

$\qquad$

Therefore:

$\qquad (a + b \div 2) \div b = \max\{n\in\Bbb{N}: b\cdot n \leq a + b \div  2\}$

$$\qquad = \max\{n\in\Bbb{N}: b\cdot n \leq a + b / 2\}, \mbox{if $b$ is even}$$

$$\qquad = \max\{n\in\Bbb{N}: n \leq a/b + 1/2\}, \mbox{if $b$ is even}$$

$$\qquad = \max\{n\in\Bbb{N}: b\cdot n \leq a + (b-1) / 2\}, \mbox{if $b$ is odd}$$

$$\qquad = \max\{n\in\Bbb{N}: n \leq a/b + 1/2 - 1/(2b)\}, \mbox{if $b$ is odd}$$

$$\qquad \overset{!}{=} \max\{n\in\Bbb{N}: n \leq a/b + 1/2\}, \mbox{if $b$ is odd}$$

$\qquad$

Proof of $\overset{!}{=}$:

$\qquad n \leq a/b + 1/2$

$\qquad \Leftrightarrow b\cdot n \leq a + b/2$

$$\qquad \Rightarrow b\cdot n \leq a + (b-1)/2,\qquad \mbox{since $b$ is odd and lhs is integer.}$$

$\qquad \Rightarrow n \leq a/b + 2/2 - 1/(2b),$

$\qquad n > a/b + 1/2 - 1/(2b),$

$$\qquad \Leftrightarrow b\cdot n > a + (b-1)/2,\qquad \mbox{since $b$ is odd and lhs is integer.}$$

$$\qquad \Rightarrow b\cdot n > a + b/2,\qquad \mbox{since $b$ is odd and lhs is integer.}$$

$\qquad \Leftrightarrow n > a/b + 1/2$