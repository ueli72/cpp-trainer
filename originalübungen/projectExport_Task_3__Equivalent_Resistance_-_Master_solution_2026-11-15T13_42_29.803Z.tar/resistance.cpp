// program that computes the equivalent resistance
// of a wiring of four resistors. R1,R2,R3 and R4
// where R1 and R2, R3 and R4 are wired in serial
// resulting in R12 and R23 that are wired in Parallel


#include <iostream>

int main() {
  // input
  std::cout << "Please enter R1\n";
  int R1;
  std::cin >> R1;
  
  std::cout << "Please enter R2\n";
  int R2;
  std::cin >> R2;
  
  std::cout << "Please enter R3\n";
  int R3;
  std::cin >> R3;
  
  std::cout << "Please enter R4\n";
  int R4;
  std::cin >> R4;

  // computation
  const int R12 = R1 + R2;
  const int R34 = R3 + R4;
  const int R = (R12 * R34 + (R12 + R34) / 2) / (R12 + R34);

  // output
  std::cout << "Equivalent resistance: " << R << "\n";
  return 0;
}